from django.shortcuts import render

# Import the studentRegistrationForm class from forms.py in the same module
from .forms import studentRegistrationForm

# This function-based view handles the requests to the root URL /. See
# urls.py for the mapping.
def student_register(request):
  # If the request method is POST, it means that the form has been submitted
  # and we need to validate it.
  if request.method == 'POST':
    # Create a studentRegistrationForm instance with the submitted data
    form = studentRegistrationForm(request.POST)
    
    # is_valid validates a form and returns True if it is valid and
    # False if it is invalid.
    if form.is_valid():
      # The form is valid and can be saved to the database
      # by calling the 'save()' method of the ModelForm instance.
      form.save()
      
      # Render the success page.
      return render(request, "templates/success.html")
  
  # This means that the request is a GET request. So we need to
  # create an instance of the studentRegistration class and render it in
  # the template
  else:
    form = studentRegistrationForm()
    
  # Render the Student registration form template with a studentRegistration instance. 
  # If the form was submitted and the data found to be invalid, the template 
  # will be rendered with the entered data and error messages. Otherwise 
  # an empty form will be rendered. Check the comments in the 
  # contact_form.html template to understand how this is done.  
  return render(request, "templates/stud_register.html", { 'form' : form })
