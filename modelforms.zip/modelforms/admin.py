from django.contrib import admin
from .models import studentRegistration


# Register your models here.
admin.site.register(studentRegistration)