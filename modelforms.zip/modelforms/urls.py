from django.conf.urls import url
from views import student_register

urlpatterns = [
    url(r'^$', student_register, name='student_register'),
]