from django.shortcuts import render
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt, csrf_protect

# Create your views here.

@csrf_exempt
def create_user(request):
	if request.method == 'POST':
		form = UserCreationForm(request.POST)
		if form.is_valid():
			form.save()	
			return render(request,'success.html', {'success':'True'})
		else:
			return render(request,'success.html', {'success':form.errors})
	else:
		form = UserCreationForm()
	return render(request, "login.html",{'forms':form})
