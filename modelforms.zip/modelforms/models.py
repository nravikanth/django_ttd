from __future__ import unicode_literals
from django.core.validators import RegexValidator

# Import the Django models ORM library
from django.db import models

class studentRegistration(models.Model):
  name = models.CharField(max_length=100)
  email = models.EmailField()
  cname = (('A', 'AKU'),
                  ('U', 'UPTU'),
                  ('C', 'CGPIT'),
                  ('S', 'SGBAU'),
                  ('N', 'No choice'))
  college_name = models.CharField(max_length=2, choices=cname,default= 'N')
  address = models.TextField()
  phone_number = models.IntegerField(unique=True, 
      validators=[RegexValidator(regex='^\d{10}$', 
      message='Please enter a valid mobile number', code='Invalid number')])
  password1 = models.CharField(max_length=20)
  password2 = models.CharField(max_length=20)
